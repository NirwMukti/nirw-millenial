package io.flutlab.hello_world.hello_world

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
